from .skNLA import Regression, Classification, Embed
